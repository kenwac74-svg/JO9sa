﻿// Local, reversible display-resource patch support.
// Supports the uploaded UTF-16LE QSPGAME format only. No network or external processes.
using System;
using System.Text;
using System.Globalization;
public static class Jo9PanelCodec {
    private static readonly Encoding U16 = new UnicodeEncoding(false, false, true);
    public static string Shift(string value, int delta) {
        char[] chars = value.ToCharArray();
        for (int i=0; i<chars.Length; ++i) chars[i]=(char)(((int)chars[i]+delta)&65535);
        return new string(chars);
    }
    public static string[] Read(byte[] bytes) {
        if ((bytes.Length & 1)!=0) throw new Exception("Unsupported odd-sized QSP file.");
        string s=U16.GetString(bytes);
        string[] f=s.Split(new string[]{"\r\n"},StringSplitOptions.None);
        if(f.Length<5 || f[0]!="QSPGAME") throw new Exception("Not the supported QSPGAME format.");
        int n=int.Parse(Shift(f[3],5),CultureInfo.InvariantCulture);
        if(n<1 || n>100000)throw new Exception("Invalid location count.");
        int at=4;
        for(int k=0;k<n;++k){
            if(at+3>=f.Length)throw new Exception("Truncated QSP location.");
            int acts=int.Parse(Shift(f[at+3],5),CultureInfo.InvariantCulture);
            if(acts<0 || acts>100000)throw new Exception("Invalid action count.");
            at=checked(at+4+acts*3);
        }
        if(at!=f.Length-1 || f[at]!="")throw new Exception("Unexpected QSP trailing fields.");
        return f;
    }
    public static int BodyIndex(string[] f,string name){
        int n=int.Parse(Shift(f[3],5),CultureInfo.InvariantCulture),at=4,found=-1;
        for(int k=0;k<n;++k){
            if(Shift(f[at],5)==name){if(found>=0)throw new Exception("Duplicate location name.");found=at+2;}
            int acts=int.Parse(Shift(f[at+3],5),CultureInfo.InvariantCulture);at+=4+acts*3;
        }
        if(found<0)throw new Exception("Required location not found: "+name);
        return found;
    }
    public static string ReplaceOnce(string text,string before,string after){
        if(String.IsNullOrEmpty(before))throw new Exception("Empty patch pattern.");
        int p=text.IndexOf(before,StringComparison.Ordinal);
        if(p<0 || text.IndexOf(before,p+before.Length,StringComparison.Ordinal)>=0)
            throw new Exception("Patch pattern must occur exactly once.");
        return text.Substring(0,p)+after+text.Substring(p+before.Length);
    }
    public static byte[] Write(string[] fields){return U16.GetBytes(String.Join("\r\n",fields));}

    public static string ReplaceChecked(string text,string before,string after,int expected){
        int count=0,at=0;while((at=text.IndexOf(before,at,StringComparison.Ordinal))>=0){count++;at+=before.Length;}
        if(count!=expected)throw new Exception("Patch pattern count mismatch: "+count+" != "+expected);
        return text.Replace(before,after);
    }
}
