﻿JO9 UI v1.9.14 누적 통합팩 R2

이전 ZIP을 순서대로 설치할 필요가 없습니다. 순정 한국어 2.3.2.5 또는 확인된 이전 UI 패치 상태에 적용합니다.
1. 게임 종료 → ZIP을 완전히 풉니다.
2. CHECK.cmd 실행 → 설치할 게임의 game/jack.qsp 선택.
3. 검사 성공 후 APPLY.cmd 실행 → 같은 jack.qsp 선택.
4. 되돌리려면 반드시 이 R2 패키지의 RESTORE.cmd를 실행합니다. 최신 미복구 설치부터 한 단계씩 되돌립니다.

포함: 확정 버튼팩, v1.0~1.5 구조, v1.6 가독성, v1.8 원본 금속, v1.9.1 수정 캐릭터 패널, 행동력·초과·적립 UI, 시설 프레임, 경량 리소스, 상단 정렬/툴팁, 검은 선 재도색 엔진 수정, 기본 폰트 복원과 상단 글꼴, v1.9.14 금속 구분선·체크박스 정렬.
R2 추가 리소스: content/pic/bg/trophy/trophywall.png, Trophy.png, content/pic/bg/slave_psychology/1.png~7.png. 제공 파일은 크기 변경이나 재압축 없이 바이트 그대로 포함합니다. trophywall.png를 새로 호출하는 QSP/CSS 코드는 추가하지 않습니다.
중간에 폐기한 전체 폰트 강제 변경·대형 이미지는 최종 상태로 대체됩니다.

세이브·NPC·일반 장소 배경·컷신은 설치 대상이 아닙니다. 공통 UI 및 기존 트로피 화면 배경 프레임은 포함됩니다. 버튼과 공통 UI 이미지 및 base.css는 통합팩 상태로 교체됩니다. jack.qsp는 검증된 5개 UI 관련 구역만 갱신합니다. 다른 구역은 유지합니다.
알 수 없는 UI 구역, CSS, 실행 파일 버전은 적용 전 차단합니다. 순정 엔진과 이전 v1.9.11 재도색 수정 엔진을 지원하며, 별도 커스텀 엔진은 사전 검사에서 중단됩니다.
기본 fonts 폴더는 기존 게임 것을 사용합니다.

백업: game/_JO9_UI_ALL1914_BACKUPS. R1/R2가 같은 백업 계열을 사용합니다. 백업은 삭제하지 마세요. 설치 후 다른 변경이 생기면 복구가 이를 덮어쓰지 않고 중단됩니다. 이미 설치된 최종 파일은 다시 쓰지 않습니다.
설치기는 UTF-8 BOM이며 Windows PowerShell 5.1을 사용합니다.


[R2 FIX1 CSS 호환성 수정]
오래된 R1 배포본을 재빌드 기준으로 사용하면서 누락됐던, 실제 JO9 UI 패치 이력으로 확인된 base.css 상태 4개를 CssBefore 허용 목록에 복원했습니다. CSS 무조건 허용으로 변경한 것이 아닙니다. 미지원 CSS가 발견되면 오류 메시지에 SHA-256을 함께 표시합니다.

[R2 FIX2 CSS 호환성 수정]
CHECK에서 보고된 현재 게임 base.css SHA-256 2c1c06d6a5ed8c7f919b4d4c82e8653fa69aa5d572913d74d7b72301efa9d2fa를 명시적으로 CssBefore 허용 목록에 추가했습니다. CSS 보호 검사는 그대로 유지합니다.


[FIX3 engine compatibility]
- jack.exe is no longer a global installation prerequisite.
- Stock verified jack.exe: install the packaged repaint-fixed engine (verified Qt5Widgets.dll required).
- Already repaint-fixed jack.exe: keep it unchanged.
- Any other/custom jack.exe: preserve it byte-for-byte and continue installing QSP/CSS/images; the repaint-engine fix is skipped.
- Extra folders such as sex_scenes are not scanned or modified.

[FIX5]
- 최신 트로피룸 배경 content/pic/bg/trophy/bg_trophy.png 반영.
- Trophy.png / trophywall.png / slave_psychology 1~7.png 유지.


[FIX5 추가]
- JO9_UI_buttons.zip의 버튼 UI 개선 16개 파일을 누적 payload에 추가했습니다.
- 대상 경로: content/pic/buttons/ 아래 16종
- FIX4의 bg_trophy 최신본 및 R2 누적 리소스는 그대로 유지됩니다.

[FIX6 레이어/정렬 수정]
- 노예/조수 `종합정보` 상세 창의 배경·본문·닫기 요소를 메인 화면 UI보다 높은 레이어로 올려 창고/우리/사이드 UI가 상세 창 위로 침범하지 않도록 수정했습니다.
- 집 내부 방 전환 버튼(`#fast_interior`)의 내부 아이콘을 1px 위로 보정해 같은 상단 유틸리티 버튼열과 시각적 정렬을 맞췄습니다.
- 노예/조수 상세 능력치 화면의 취소/닫기 버튼(`#close`)을 1px 위로 보정했습니다.
- 이미지와 QSP 코드는 변경하지 않았습니다. FIX5 누적 리소스, 엔진 정책, QSP 5-location 패치, CSS 안전 검사는 그대로 유지합니다.
