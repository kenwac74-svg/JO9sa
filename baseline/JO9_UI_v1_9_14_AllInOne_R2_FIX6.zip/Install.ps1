﻿param(
    [ValidateSet('Check','Apply','Restore')][string]$Mode='Apply',
    [string]$GamePath='',
    [switch]$NonInteractive
)
$ErrorActionPreference='Stop'
Set-StrictMode -Version 2
$Root=$PSScriptRoot
$Utf8=New-Object Text.UTF8Encoding($false,$true)
$Utf8Bom=New-Object Text.UTF8Encoding($true,$true)
$script:Forms=$false
function Tell([string]$text){Write-Host $text; if($script:Forms){[void][Windows.Forms.MessageBox]::Show($text,'JO9 UI v1.9.14 All-in-One R2','OK','Information')}}
function Hash([string]$file){return (Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash.ToLowerInvariant()}
function HashBytes([byte[]]$data){$h=[Security.Cryptography.SHA256]::Create();try{return [BitConverter]::ToString($h.ComputeHash($data)).Replace('-','').ToLowerInvariant()}finally{$h.Dispose()}}
function Bytes([string]$text,[bool]$bom){if($bom){return [byte[]]($Utf8Bom.GetPreamble()+$Utf8.GetBytes($text))};return $Utf8.GetBytes($text)}
function ReadText([string]$file){$b=[IO.File]::ReadAllBytes($file);$bom=$b.Length-ge 3-and $b[0]-eq 239-and $b[1]-eq 187-and $b[2]-eq 191;$skip=0;if($bom){$skip=3};return [pscustomobject]@{Text=$Utf8.GetString($b,$skip,$b.Length-$skip);Bom=$bom}}
function SafePath([string]$base,[string]$rel){
    $base=[IO.Path]::GetFullPath($base).TrimEnd('\')
    $full=[IO.Path]::GetFullPath((Join-Path $base $rel))
    if(-not $full.StartsWith($base+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Path escaped the selected folder.'}
    $scan=$full
    while($scan.Length-ge $base.Length){
        if(Test-Path -LiteralPath $scan){if(((Get-Item -LiteralPath $scan -Force).Attributes-band [IO.FileAttributes]::ReparsePoint)-ne 0){throw ('Symlink/junction not supported: '+$scan)}}
        if($scan-eq $base){break};$scan=[IO.Path]::GetDirectoryName($scan)
    }
    return $full
}
function Commit([string]$file,[byte[]]$data){
    $tmp=$file+'.jo9v1914-'+[Guid]::NewGuid().ToString('N')+'.tmp'
    $spare=$tmp+'.bak'
    try{[IO.File]::WriteAllBytes($tmp,$data);if([IO.File]::Exists($file)){[IO.File]::Replace($tmp,$file,$spare)}else{[IO.File]::Move($tmp,$file)}}finally{if([IO.File]::Exists($tmp)){[IO.File]::Delete($tmp)}}
    if((Hash $file)-ne (HashBytes $data)){throw ('Write verification failed: '+$file)}
    if([IO.File]::Exists($spare)){[IO.File]::Delete($spare)}
}
function SaveState($state,[string]$file){[IO.File]::WriteAllText($file,($state|ConvertTo-Json -Depth 8),$Utf8Bom)}
function RestoreRecord($state,[string]$folder){
    $allowed=@('content/pic/bg/slave_psychology/1.png','content/pic/bg/slave_psychology/2.png','content/pic/bg/slave_psychology/3.png','content/pic/bg/slave_psychology/4.png','content/pic/bg/slave_psychology/5.png','content/pic/bg/slave_psychology/6.png','content/pic/bg/slave_psychology/7.png','content/pic/bg/trophy/bg_trophy.png','content/pic/bg/trophy/Trophy.png','content/pic/bg/trophy/trophywall.png','content/pic/buttons/approve.png','content/pic/buttons/approve_small.png','content/pic/buttons/auk_next.png','content/pic/buttons/close_button.png','content/pic/buttons/debug_a.png','content/pic/buttons/debug_s.png','content/pic/buttons/deny.png','content/pic/buttons/evaluate.png','content/pic/buttons/fast_cook.png','content/pic/buttons/fast_milking.png','content/pic/buttons/fast_milking_gray.png','content/pic/buttons/fast_punishment.png','content/pic/buttons/fast_reward.png','content/pic/buttons/fast_sweep.png','content/pic/buttons/fast_wash.png','content/pic/buttons/fast_wash_assistant.png','content/pic/buttons/gear.png','content/pic/buttons/gear_console.png','content/pic/buttons/gear_slave_editor.png','content/pic/buttons/imprison.png','content/pic/buttons/influence.png','content/pic/buttons/jo9_heart_a.png','content/pic/buttons/jo9_heart_s.png','content/pic/buttons/lab.png','content/pic/buttons/milk_drop_large.png','content/pic/buttons/Minus.png','content/pic/buttons/Minus_small.png','content/pic/buttons/net_active.png','content/pic/buttons/net_used.png','content/pic/buttons/ok-icon.png','content/pic/buttons/Plus.png','content/pic/buttons/Plus_small.png','content/pic/buttons/question.png','content/pic/buttons/release.png','content/pic/buttons/rise_up.png','content/pic/buttons/sel_button.png','content/pic/buttons/shield_active.png','content/pic/buttons/shield_used.png','content/pic/buttons/soc_btn.png','content/pic/buttons/sound_off.png','content/pic/buttons/sound_on.png','content/pic/buttons/study_button.png','content/pic/buttons/study_button_gray.png','content/pic/buttons/teach.png','content/pic/buttons/thumb_down.png','content/pic/buttons/thumb_up.png','content/pic/buttons/trotest.png','content/pic/buttons/unactive_button.png','content/pic/buttons/unsel_button.png','content/pic/buttons/whip_active.png','content/pic/buttons/whip_used.png','content/pic/buttons/yellow_button.png','content/pic/buttons/z_ill.png','content/pic/buttons/z_pregnant.png','content/pic/buttons/z_wounds.png','content/pic/ui/approved_main_v1/action_clean.png','content/pic/ui/approved_main_v1/action_cook.png','content/pic/ui/approved_main_v1/action_heart_a.png','content/pic/ui/approved_main_v1/action_heart_s.png','content/pic/ui/approved_main_v1/action_influence.png','content/pic/ui/approved_main_v1/action_info_a.png','content/pic/ui/approved_main_v1/action_info_s.png','content/pic/ui/approved_main_v1/action_milking.png','content/pic/ui/approved_main_v1/action_milking_gray.png','content/pic/ui/approved_main_v1/action_punish.png','content/pic/ui/approved_main_v1/action_question.png','content/pic/ui/approved_main_v1/action_reward.png','content/pic/ui/approved_main_v1/action_social.png','content/pic/ui/approved_main_v1/action_wash.png','content/pic/ui/approved_main_v1/action_wash_a.png','content/pic/ui/approved_main_v1/header_trophy.png','content/pic/ui/approved_main_v1/role_swap_hook.png','content/pic/ui/approved_main_v1/role_swap_sa.png','content/pic/ui/approved_main_v1/tool_room.png','content/pic/ui/grimdark/bg.png','content/pic/ui/grimdark/bg_fight.png','content/pic/ui/grimdark/bg_main.png','content/pic/ui/grimdark/bg_ride.png','content/pic/ui/grimdark/bg_stat.png','content/pic/ui/grimdark/buttons/gear.png','content/pic/ui/grimdark/buttons/sound_off.png','content/pic/ui/grimdark/buttons/sound_on.png','content/pic/ui/jo9_v197/06cfa32964c1.png','content/pic/ui/jo9_v197/2a81e31d426f.png','content/pic/ui/jo9_v197/49cdec4e6773.png','content/pic/ui/jo9_v197/4a0c7f1e9e75.png','content/pic/ui/jo9_v197/5d095d34b115.png','content/pic/ui/jo9_v197/728644846d9c.png','content/pic/ui/jo9_v197/a64f99c80000.png','content/pic/ui/jo9_v197/b974654aedb1.png','content/pic/ui/jo9_v197/d5977d72c018.png','content/pic/ui/jo9_v197/exit.png','content/pic/ui/jo9_v197/f36145a03cb3.png','content/pic/ui/jo9_v197/home.png','content/pic/ui/jon-UIadds/equipment.png','content/pic/ui/jon-UIadds/Fer_가임.png','content/pic/ui/jon-UIadds/Fer_불임.png','content/pic/ui/jon-UIadds/Fer_산란.png','content/pic/ui/jon-UIadds/Fer_아동.png','content/pic/ui/jon-UIadds/milk_drop.png','content/pic/ui/jon-UIadds/milk_drop_no.png','content/pic/ui/jon-UIadds/Vir_restored.png','content/pic/ui/jon-UIadds/Vir_shriveled.png','content/pic/ui/jon-UIadds/Vir_비.png','content/pic/ui/jon-UIadds/Vir_처.png','css/base.css','engine/jack.exe','jack.qsp')
    # Validate every file before restoring any file; never overwrite unrelated edits.
    foreach($e in $state.Files){
        if($allowed -notcontains $e.Rel){throw 'Unexpected file in backup record.'}
        $target=SafePath $GamePath $e.Rel;$backup=SafePath (Join-Path $folder 'original') $e.Rel
        if($e.Existed -and (Hash $backup)-ne $e.Before){throw ('Backup hash mismatch: '+$e.Rel)}
        $current='ABSENT';if(Test-Path -LiteralPath $target){$current=Hash $target}
        if($current-ne $e.Before-and $current-ne $e.After){throw ('File changed since installation; refusing to overwrite: '+$e.Rel)}
    }
    foreach($e in @($state.Files)[($state.Files.Count-1)..0]){
        $target=SafePath $GamePath $e.Rel
        if($e.Existed){if((Hash $target)-ne $e.Before){Commit $target ([IO.File]::ReadAllBytes((SafePath (Join-Path $folder 'original') $e.Rel)))}}elseif(Test-Path -LiteralPath $target){[IO.File]::Delete($target)}
    }
    $state.Status='restored';SaveState $state (Join-Path $folder 'state.json')
}
try {
    if(-not $NonInteractive){Add-Type -AssemblyName System.Windows.Forms;$script:Forms=$true}
    if([string]::IsNullOrWhiteSpace($GamePath)){
        if($NonInteractive){throw 'Provide -GamePath with the game folder or jack.qsp.'}
        $dialog=New-Object Windows.Forms.OpenFileDialog
        $dialog.Title='JO9 UI v1.9.14 All-in-One R2 FIX6 - Select game/jack.qsp';$dialog.Filter='Jack game|jack.qsp';$dialog.CheckFileExists=$true
        try{if($dialog.ShowDialog()-ne 'OK'){exit 0};$GamePath=$dialog.FileName}finally{$dialog.Dispose()}
    }
    $GamePath=[IO.Path]::GetFullPath($GamePath.Trim().Trim('"'))
    if([IO.File]::Exists($GamePath)){$GamePath=[IO.Path]::GetDirectoryName($GamePath)}
    $qsp=SafePath $GamePath 'jack.qsp';$css=SafePath $GamePath 'css/base.css'
    if(-not [IO.File]::Exists($qsp)-or -not [IO.File]::Exists($css)){throw 'Select the actual game folder containing jack.qsp and css/base.css.'}
    foreach($proc in Get-Process -Name jack -ErrorAction SilentlyContinue){if($proc.Path -and [IO.Path]::GetFullPath($proc.Path)-eq (Join-Path $GamePath 'engine/jack.exe')){throw 'Close this game before installation or restore.'}}
    $backupRoot=SafePath $GamePath '_JO9_UI_ALL1914_BACKUPS'
    if($Mode-eq 'Restore'){
        $found=$null
        if(Test-Path -LiteralPath $backupRoot){foreach($dir in Get-ChildItem -LiteralPath $backupRoot -Directory | Sort-Object Name -Descending){
            $record=Join-Path $dir.FullName 'state.json'
            if(Test-Path -LiteralPath $record){$s=Get-Content -LiteralPath $record -Raw -Encoding UTF8|ConvertFrom-Json;if($s.Package-eq 'JO9_UI_ALL1914' -and $s.Status-ne 'restored'){$found=$dir;$state=$s;break}}
        }}
        if($null-eq $found){throw 'No active v1.9.14 All-in-One backup found.'}
        if($script:Forms -and [Windows.Forms.MessageBox]::Show('Close the game. Restore the pre-v1.9.14 All-in-One files?','JO9 v1.9.14 All-in-One R2 FIX6','YesNo','Question')-ne 'Yes'){exit 0}
        RestoreRecord $state $found.FullName
        Tell 'Restored the pre-v1.9.14 All-in-One files. The state before this cumulative installation is restored.';exit 0
    }
    $manifest=Get-Content -LiteralPath (Join-Path $Root 'manifest.json') -Raw -Encoding UTF8|ConvertFrom-Json
    foreach($entry in $manifest.Payload){if((Hash (SafePath $Root $entry.Rel))-ne $entry.Hash){throw ('Damaged package: '+$entry.Rel)}}
    Add-Type -Path (Join-Path $Root 'PanelCodec.cs')
    $fields=[Jo9PanelCodec]::Read([IO.File]::ReadAllBytes($qsp))
    $patches=Get-Content -LiteralPath (Join-Path $Root 'qsp-patches.json') -Raw -Encoding UTF8|ConvertFrom-Json
    foreach($patch in $patches){
        $idx=[Jo9PanelCodec]::BodyIndex($fields,$patch.Name)
        $body=[Jo9PanelCodec]::Shift($fields[$idx],5);$h=HashBytes ($Utf8.GetBytes($body))
        if($h-eq $patch.After){continue}
        if($patch.Before -notcontains $h){throw ('Unsupported modified UI location: '+$patch.Name+'. No files changed.')}
        $fields[$idx]=[Jo9PanelCodec]::Shift($patch.Text,-5)
    }
    $cssHash=Hash $css
    if($manifest.CssBefore -notcontains $cssHash){throw ('Unsupported modified base.css: '+$cssHash+'. No files changed.')}
    $engine=SafePath $GamePath 'engine/jack.exe'
    $engineHash='ABSENT';if([IO.File]::Exists($engine)){$engineHash=Hash $engine}
    $replaceEngine=$false;$engineMessage=''
    if($engineHash-eq $manifest.EngineBefore){
        $qtWidgets=SafePath $GamePath 'engine/Qt5Widgets.dll'
        if(-not [IO.File]::Exists($qtWidgets)-or (Hash $qtWidgets)-ne $manifest.QtWidgetsHash){throw 'Stock jack.exe detected, but Qt5Widgets.dll is not the verified matching version. No files changed.'}
        $replaceEngine=$true
        $engineMessage='Stock jack.exe detected: repaint-fixed jack.exe will be installed.'
    }elseif($engineHash-eq $manifest.EngineAfter){
        $engineMessage='Repaint-fixed jack.exe is already installed; engine will be left unchanged.'
    }else{
        $engineMessage=('Custom jack.exe preserved unchanged (SHA-256: '+$engineHash+'). Repaint-engine fix will be skipped.')
        Write-Warning $engineMessage
    }
    $plan=New-Object Collections.Generic.List[object]
    $qbytes=[Jo9PanelCodec]::Write($fields)
    if((HashBytes $qbytes)-ne (Hash $qsp)){$plan.Add([pscustomobject]@{Rel='jack.qsp';Data=$qbytes})}
    foreach($entry in $manifest.Files){
        if($entry.Rel-eq 'engine/jack.exe'-and -not $replaceEngine){continue}
        $target=SafePath $GamePath $entry.Rel
        if([IO.File]::Exists($target)-and (Hash $target)-eq $entry.After){continue}
        $data=[IO.File]::ReadAllBytes((SafePath $Root $entry.Source))
        $plan.Add([pscustomobject]@{Rel=$entry.Rel;Data=$data})
    }
    if($plan.Count-eq 0){Tell ('All cumulative v1.9.14 R2 FIX6 files are already installed.'+"`r`n"+$engineMessage);exit 0}
    $entries=foreach($p in $plan){$target=SafePath $GamePath $p.Rel;$exists=[IO.File]::Exists($target);$before='ABSENT';if($exists){$before=Hash $target};[pscustomobject]@{Rel=$p.Rel;Existed=$exists;Before=$before;After=(HashBytes $p.Data)}}
    if($Mode-eq 'Check'){Tell ('CHECK OK: '+$plan.Count+' files prepared in memory; no game files changed.'+"`r`n"+$engineMessage);exit 0}
    if($script:Forms -and [Windows.Forms.MessageBox]::Show('Close the game. Apply UI v1.9.14 All-in-One R2? A backup will be created.','JO9 v1.9.14 All-in-One R2 FIX6','YesNo','Question')-ne 'Yes'){exit 0}
    $folder=Join-Path $backupRoot ((Get-Date).ToString('yyyyMMdd_HHmmss')+'_'+[Guid]::NewGuid().ToString('N').Substring(0,8))
    foreach($e in $entries){$target=SafePath $GamePath $e.Rel;$b=SafePath (Join-Path $folder 'original') $e.Rel;[void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($b));if($e.Existed){[IO.File]::Copy($target,$b);if((Hash $b)-ne $e.Before){throw 'A file changed while creating the backup.'}}}
    $state=[pscustomobject]@{Package='JO9_UI_ALL1914';Status='applying';Files=@($entries)}
    SaveState $state (Join-Path $folder 'state.json')
    try{
        for($i=0;$i-lt $plan.Count;$i++){$p=$plan[$i];$target=SafePath $GamePath $p.Rel;$now='ABSENT';if([IO.File]::Exists($target)){$now=Hash $target};if($now-ne $entries[$i].Before){throw ('File changed during install: '+$p.Rel)};[void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($target));Commit $target $p.Data}
        $state.Status='applied';SaveState $state (Join-Path $folder 'state.json')
    }catch{
        $reason=$_.Exception.Message
        try{RestoreRecord $state $folder}catch{Write-Warning ('Automatic restore failed: '+$_.Exception.Message+'; backup: '+$folder)}
        throw $reason
    }
    Tell ('Cumulative UI/buttons v1.9.14 R2 FIX6 installed, including the existing cumulative resources and the UI alignment/layer fixes.'+"`r`n"+$engineMessage+"`r`n"+'Restart the game.'+"`r`n"+'Backup: '+$folder)
}catch{
    Write-Host ('[JO9 v1.9.14 All-in-One R2 ERROR] '+$_.Exception.Message) -ForegroundColor Red
    if($script:Forms){[void][Windows.Forms.MessageBox]::Show($_.Exception.Message,'JO9 v1.9.14 All-in-One R2 FIX6','OK','Error')}
    exit 1
}
